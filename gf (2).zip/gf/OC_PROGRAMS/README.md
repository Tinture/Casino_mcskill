# OpenComputers Casino


### Requirements
* OpenComputers
* Computronics
* Iron Chests (for now)


